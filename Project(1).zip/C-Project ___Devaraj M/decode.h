#ifndef DECODE_H
#define DECODE_H


#include "types.h"

//#define MAX_SECRET_BUF_SIZE 1
//#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8 )
//#define MAX_FILE_SUFFIX 4

typedef struct _DecodeInfo
{
    char *desrc_image_fname;
    FILE *fptr_desrc_image;

    char desecret_fname[50];
    FILE *fptr_desecret;
 
    char magic_string[50];
    char secret_extn[5];
    
    int stored_data;
    int extn_size;

}DecodeInfo;


Status read_and_validate_decode_args (char *argv[], DecodeInfo *decInfo );

Status do_decoding(DecodeInfo *decInfo);

Status decode_open_files(DecodeInfo *decInfo);

Status decode_magic_string(DecodeInfo *decInfo);

Status decode_data_to_image(DecodeInfo *decInfo, FILE *fptr_desrc_image,int size);

Status decode_byte_to_lsb(DecodeInfo *decInfo,char *arr,int j);

Status decode_secret_file_extn_size(DecodeInfo *decInfo);

Status decode_secret_file_extn(DecodeInfo *decInfo);

Status decode_size_to_lsb(DecodeInfo *decInfo,char *ptr);

Status decode_secret_file_size(DecodeInfo *decInfo);

Status decode_secret_file_data(DecodeInfo *decInfo);









#endif

