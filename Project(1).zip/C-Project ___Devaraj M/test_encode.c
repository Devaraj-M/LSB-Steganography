/*
NAME    	: DEVARAJ M
DATE    	: 22-12-2023
PROJECT 	: Steganography
*/


#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "decode.h"

int main(int argc, char *argv[])
{
    int ret;
    if(argc != 1)
    {
    	ret = check_operation_type(argv);

	EncodeInfo encInfo;
	DecodeInfo decInfo;

	if(ret == e_encode)
	{
	    printf(">.................SELECTED ENCODE...................<\n");

	    if(read_and_validate_encode_args(argv, &encInfo) == e_success)
	    {
		printf("INFO: read_and_validate_encode_argts done\n");
		if(do_encoding(&encInfo) == e_success)
		{
		    printf("<.....ENCODED SUCCESSFULLY.....>\n");
		}
		else
		{
		    printf(".....ENCODE FAILED.....\n");
		}
	    }
	}
	else if(ret == e_decode)
	{
	    printf(">..................SELECTED DECODE...................<\n");
	    if(read_and_validate_decode_args(argv, &decInfo) == e_success)
	    {
		printf("INFO: read_and_validate_encode_args has successfully done.\n");
		if(do_decoding(&decInfo) == e_success)
		{
		    printf("<.....DECODED SUCCESSFULLY.....>\n");
		}
		else
		{
		    printf("<.....DECODE FAILED.....>\n");
		}
	    }
	}
	else
	{
	    printf("ERROR : Pass the valid 1st Arguments\n");
	}
    }
    else
    {
	printf("ERROR : Pass the arguments in Command Line\n");
    }
}

OperationType check_operation_type(char *argv[])
{
    if(strcmp(argv[1],"-e") == 0)
    {
	return e_encode;
    }
    else if(strcmp(argv[1],"-d") == 0)
    {
	return e_decode;
    }
}
