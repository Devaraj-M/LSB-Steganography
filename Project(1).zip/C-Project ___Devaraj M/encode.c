#include <stdio.h>
#include "encode.h"
#include "types.h"
#include<string.h>
#include "common.h"
/* Function Definitions */

/* check argv[0] is .bmp file
   yes -> stroe it in  encInfo -> src_image_frame
   no -> return e_failure



   check argv[1] is text.file
   yes -> store it in encInfo -> secret_fname
   no -> return e_failure


   check argv[2] is passed or not 
   passed -> check argv[2] is .bmp

   yes -> store in encInfo -> stego_image_fname
   no ->return e_failure

   not passed  -> encInfo -> stego_image_fname = "default.bmp"


   return e_success
 */
Status read_and_validate_encode_args(char *argv[],EncodeInfo *encInfo)
{
    if ( strcmp( strstr (argv[2],"."), ".bmp") == 0 )
    {
	encInfo ->src_image_fname = argv[2];
    }
    else
    {
	return e_failure;
    }

    //if  ((strcmp( strstr ( argv[3],"."),".txt")) == 0 )
    if ( ((strcmp( strstr ( argv[3],"."),".txt")==0 )|| (strcmp( strstr ( argv[3],"."),".sh") == 0 )|| (strcmp( strstr ( argv[3],"."),".c"))== 0 ) == 1)
    {
	encInfo ->secret_fname = argv[3];
	strcpy(encInfo -> extn_secret_file, strstr(argv[3], "."));
    }
    else
    {
	return e_failure;
    }

    if ( argv[4] == NULL )
    {
	encInfo -> stego_image_fname = "default.bmp";
    }
    else if ( strcmp ( strstr( argv[4],"."),".bmp") == 0 )
    {
	encInfo -> stego_image_fname= argv[4];
    }
    else
    {
	return e_failure;
    }

    return e_success;    
}


Status do_encoding(EncodeInfo *encInfo)
{
    if ( open_files(encInfo)==e_success)
    {
	// printf("INFO: Opened SkeletonCode/beautiful.bmp\n");
	printf("INFO: Done\n");
	printf("INFO: <..... ENCODE  STARTED .....>\n");
	if( check_capacity (encInfo) == e_success )
	{
	    //Checking capacity success
	    printf("INFO: Done. Found OK\n");
	    printf("INFO: Output File not mentioned. Creating steged_img.bmp as default\n");

	    if(copy_bmp_header ( encInfo -> fptr_src_image , encInfo -> fptr_stego_image ) == e_success )
	    {
		//encoding BMP header success
		printf("INFO: Done\n");

		if ( encode_magic_string(MAGIC_STRING , encInfo) == e_success )
		{
		    //Encoding magic string success
		    printf("INFO: Done\n");
		    /*
		       read 32 bytes from the fptr src image
		       encode_size_to_lsb(size,str)
		       write 32 bytes
		       return e_success
		     */


		    if ( encode_secret_file_extn_size(strlen(encInfo -> extn_secret_file),encInfo -> fptr_src_image,encInfo->fptr_stego_image) == e_success)
		    {
			//encoding secret file extension size  success
			if( encode_secret_file_extn (encInfo -> extn_secret_file,encInfo ) == e_success )
			{
			    //encoding secret file extension  success
			    printf("INFO: Done\n");



			    if ( encode_secret_file_size ( encInfo -> size_secret_file, encInfo) == e_success )
			    {
				//encoding secret file size succes
				printf("INFO: Done\n");


				if( encode_secret_file_data (encInfo ) == e_success )
				{
				    //encoding secret file data success
				    printf("INFO: Done\n");

				    if (copy_remaining_img_data(encInfo -> fptr_src_image,encInfo -> fptr_stego_image) == e_success)
				    {
					//encodig Remaining data success
					printf("INFO: Done\n");

					return e_success;
				    }
				    else
				    {
					printf("INFO:  Encoding Remaining data Not Done\n");
					return e_failure;
				    }
				}
				else
				{
				    printf("INFO:  Encoding secret file Not Done\n");
				    return e_failure;
				}
			    }
			    else
			    {
				printf("INFO:  Encoding secret file size Not Done\n");
				return e_failure;
			    }

			}
			else
			{
			    printf("INFO:  Encoding secret file extension Size Not Done\n");
			    return e_failure;
			}
		    }
		    else
		    {
			printf("INFO:  Encoding secret file extension Not Done\n");
			return e_failure;
		    }

		}
		else
		{
		    printf("INFO:  Encoding magic string Not Done\n"); 
		    return e_failure;

		}
	    }

	    else
	    {
		printf("INFO: Encoding BMP header Not Done\n");

		return e_failure;

	    }

	}
	else
	{

	    printf("INFO: Cheking Capacity Not Done\n");
	    return e_failure;
	}
    }
    else
    {

	printf("INFO: OPening files Not Done\n");

    }

}


//find the .bmp file size
Status check_capacity (EncodeInfo *encInfo)
{
    encInfo -> size_secret_file = get_file_size(encInfo -> fptr_secret);
    if( encInfo -> size_secret_file > 0 )
    {
	printf("INFO: Done. Not Empty\n");
    }
    encInfo -> image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image);
    if( encInfo -> image_capacity > 0 )
    { 
	printf("INFO: Checking for SkeletonCode/beautiful.bmp capacity to handle secret%s\n",encInfo ->extn_secret_file);
    }


    if(encInfo -> image_capacity >((strlen(MAGIC_STRING)*8)+32+32+32+(encInfo -> size_secret_file * 8)))
    {
	return e_success;
    }
    else
    {
	return e_failure;
    }
}


//move the file pointer ti last
//use ftell to get the file pointer position ( return ftell)
uint get_file_size(FILE *fptr)
{
    printf("INFO: Checking for secret.txt size\n");
    fseek(fptr,0,SEEK_END);
    return ftell(fptr);

}


/*
   move the fptr_src_image to first position 
   char str[54]
   use fread function -> read 54 bytes
   fwrite -> write 54 bytes in fptr_dest_image 
   return e_success
 */
Status copy_bmp_header(FILE *fptr_src_image,FILE *fptr_stego_image)
{
    char str[54];
    rewind(fptr_src_image);
    fread (str,54,1,fptr_src_image);
    fwrite(str,54,1,fptr_stego_image);
    printf("INFO: Copying Image Header\n");
    return e_success;
}


Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo )
{
    encode_data_to_image ( magic_string, strlen(magic_string), encInfo -> fptr_src_image,encInfo -> fptr_stego_image );
    printf("INFO: Encoding Magic String Signature\n");
    return e_success;
}


Status encode_data_to_image (const char *data , int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char str[8];
    for( int i=0; i<size;i++ )
    {
	fread(str,8,1,fptr_src_image);
	encode_byte_to_lsb(data[i],str);
	fwrite(str,8,1,fptr_stego_image);
    }
}


/*
   read 32 bytes from the fptr src image
   encode_size_to_lsb(size,str)
   write 32 bytes
   return e_success
*/
Status encode_secret_file_extn_size ( int size, FILE *fptr_src_image,FILE *fptr_stego_image )
{
    char str[32];
    fread(str,32,1,fptr_src_image);
    encode_size_to_lsb(size,str);
    fwrite(str,32,1,fptr_stego_image);

    return e_success;
}


Status encode_secret_file_extn(const char *file_extn,EncodeInfo *encInfo)
{
    encode_data_to_image(file_extn,strlen(file_extn),encInfo -> fptr_src_image,encInfo -> fptr_stego_image);
    printf("INFO: Encoding secret%s File Extenstion\n",encInfo -> extn_secret_file);
    return e_success;
}


Status encode_secret_file_size(long file_size,EncodeInfo *encInfo)
{
    char str[32];
    fread(str,32,1,encInfo -> fptr_src_image);
    encode_size_to_lsb(file_size,str);
    fwrite(str,32,1,encInfo -> fptr_stego_image);

    printf("INFO: Encoding secret%s File Size\n",encInfo -> extn_secret_file);
    return e_success;
}


Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char arr[encInfo -> size_secret_file];
    rewind(encInfo -> fptr_secret);
    fread(arr,sizeof(arr),1,encInfo -> fptr_secret);
    encode_data_to_image(arr,strlen(arr),encInfo -> fptr_src_image,encInfo -> fptr_stego_image);
    printf("INFO: Encoding secret%s File Data\n",encInfo -> extn_secret_file);
    return e_success;
}


Status copy_remaining_img_data(FILE *fptr_src,FILE *fptr_dest)
{
    char copy;
    while(fread(&copy,sizeof(char),1,fptr_src) > 0)
    {
	fwrite(&copy,sizeof(char),1,fptr_dest);
    }
    printf("INFO: Copying Left Over Data\n");
    return e_success;
}


Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for( int i = 7; i >= 0; i-- )
    {
	image_buffer[7-i] = (image_buffer[7-i] & 0XFE ) | (data & (1 << i )) >> i;
    }
}


Status encode_size_to_lsb ( int size, char *image_buffer)
{
    for( int i =31; i>=0; i-- )
    {
	image_buffer [31-i] = (image_buffer[31-i] & ~1 ) | (size & (1 << i)) >> i;
    }
}


/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    //printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    //printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    printf("INFO: Opening required files\n");
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

	return e_failure;
    }
    else
    {

	printf("INFO: Opened SkeletonCode/beautiful.bmp\n");
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

	return e_failure;
    }
    else
    {
	printf("INFO: Opened secret%s\n",encInfo -> extn_secret_file);
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

	return e_failure;
    }
    else
    {
	printf("INFO: Opened %s\n",encInfo -> stego_image_fname );
    }

    // No failure return e_success
    return e_success;
}

