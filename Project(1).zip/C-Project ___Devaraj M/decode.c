#include<stdio.h>
#include<string.h>
#include "decode.h"
#include "types.h"
#include "common.h"


Status read_and_validate_decode_args(char *argv[],DecodeInfo *decInfo)
{
    if ( strcmp( strstr (argv[2],"."), ".bmp") == 0  )    	// First checking argv[2] is .bmp file or not
    {
	decInfo ->desrc_image_fname = argv[2];           	// storing that to desrc image fname
    }
    else
    {
	return e_failure;
    }

    if ( argv[3] != NULL )                                     	// checking argv[3] is passed or not
    {
	strcpy(decInfo -> desecret_fname, argv[3]);            	// store it in desecret fname
    }
    else
    {
	strcpy(decInfo -> desecret_fname , "decode_output");  		// else create new file decode_output.txt and stored in desecret fname
    }

    return e_success;
}


Status do_decoding(DecodeInfo *decInfo)
{
    printf("INFO: ## Decoding Procedure Started ##\n");

    if ( decode_open_files(decInfo)==e_success)
    {
	if( decode_magic_string(decInfo) == e_success  )
	{
	    // Decoding magic string success
	    printf("INFO: Done\n");
	    if (decode_secret_file_extn_size(decInfo) == e_success)
	    {
		//Decode secret file extn size completed success

		if( decode_secret_file_extn(decInfo) == e_success )
		{
		   // Decoding secret_file extension success
		    printf("INFO: Done\n");
		    printf("INFO: Output File not mentioned. Creating decoded.txt as default\n");
		    printf("INFO: Opened decoded.txt\n");
		    printf("INFO: Done. Opened all required files\n");


		    if(decode_secret_file_size(decInfo) == e_success)
		    {

			//Decode secret file size success
			printf("INFO: Done\n");

			if( decode_secret_file_data(decInfo) == e_success ) 
			{

			    //Decode seceret file data success
			    printf("INFO: Done\n");

			    return e_success;
			}
			else
			{
			    printf("Deocode seceret file data unsuccessfull\n");
			    return e_failure;
			}
		    }
		    else
		    {
			printf("Decode secret file size unsuccesfull\n");
			return e_failure;
		    }
		}
		else
		{
		    printf("Decode secret file extn not completed successfully\n");
		    return e_failure;
		}
	    }
	    else
	    {
		printf("Decoding secret_file extension size not successfull\n");
		return e_failure;
	    }
	}
	else
	{
	    printf("Decoding magic string failed\n");
	    return e_failure;
	}  
    }
    else
    {
	printf("Open files for decoding Failed \n");
	return e_failure;
    }
}


Status decode_open_files(DecodeInfo *decInfo)
{
    printf("INFO: Opening required files \n");                                  //Opening the decsrc ->desrc_image_fname in read mode
    decInfo->fptr_desrc_image = fopen(decInfo->desrc_image_fname, "r");
    if (decInfo->fptr_desrc_image == NULL )                        		//checking file is opened succesfully or not 
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->desrc_image_fname);

	return e_failure;
    }
    else
    {
	printf("INFO: Opened %s\n",decInfo->desecret_fname);
    }

    return e_success;
}


Status decode_magic_string( DecodeInfo *decInfo )
{
    fseek(decInfo -> fptr_desrc_image,54,SEEK_SET);					// setting the cursor_pointer to 54 position

    decode_data_to_image(decInfo,decInfo->fptr_desrc_image,strlen(MAGIC_STRING));       // function call for decode data to image
    if( strcmp(decInfo -> magic_string , MAGIC_STRING) == 0 )
    {
	printf("INFO: Decoding Magic String Signature\n");
    }
    else
   {
	return e_failure;
    }
    return e_success;
}


Status decode_data_to_image( DecodeInfo *decInfo, FILE *fptr_desrc_image,int size )
{
    char arr[8];            	
    char ch=0;                                                                 //local variable

    for( int i=0; i<size; i++ )                                                // running for loop to  size times
    {
	fread ( arr,8,1,fptr_desrc_image );                                    // getting 8 bytes from arr and storing to fptr desrc image

	decode_byte_to_lsb(decInfo,arr,i);                                     // function call for byte to lsb
    }
}


Status decode_byte_to_lsb ( DecodeInfo *decInfo, char *arr , int j )
{
    char ch=0;                                                                  	// creating local variable and making it 0

    for( int i=0 ; i<=7; i++ )
    {
	ch=(((arr[i] & 0X01 ) << (7-i)) | ch);                                         // clear, get and merge the byte
    }
    decInfo -> magic_string[j] = ch;                                                  // storing that value to magic string
}

Status decode_size_to_lsb ( DecodeInfo *decInfo, char *ptr )
{
    decInfo->stored_data = 0;
    for(int i = 0; i < 32;i++)
    {
	decInfo -> stored_data = (((ptr[i] &  0X1) << (31-i)) | decInfo -> stored_data); //clear, get and merge the bytes then store it in stored data
    }
}


Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    char ptr[32];
    fread (ptr,32,1,decInfo -> fptr_desrc_image);   			// reading 32 bytes from fptr desrc image and storing in str array
    decode_size_to_lsb(decInfo,ptr);                                    // function call for decode size to lsb
    decInfo -> extn_size = decInfo ->stored_data;


    if((decInfo -> stored_data == 4) || (decInfo -> stored_data == 3) || (decInfo -> stored_data ==2)  ) //cheking extension size
    {
	printf("INFO: Decoding Output File Extenstion\n");
	return e_success;
    }
    else
    {
	return e_failure;
    }
}


Status decode_secret_file_extn(DecodeInfo *decInfo)
{
   
    decode_data_to_image(decInfo,decInfo -> fptr_desrc_image,decInfo -> stored_data);        // function call for  decode data to image
  
    strcpy(decInfo -> secret_extn ,decInfo ->magic_string);                                 //coping the extension 

    strcat(decInfo -> desecret_fname, decInfo -> secret_extn);                             //concatenating the extension 

    decInfo->fptr_desecret=fopen(decInfo->desecret_fname,"w");
    if(decInfo -> fptr_desecret == NULL )
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->desecret_fname);
	return e_failure;
    }
    return e_success;
}

Status decode_secret_file_size(DecodeInfo *decInfo)                              
{
    char ptr[32];
    fread (ptr,1,32,decInfo -> fptr_desrc_image);                        // reading 32 bytes from fptr desrc image and storing in str array
    decode_size_to_lsb(decInfo,ptr);                                     // function call for decode size to lsb
    printf("INFO: Decoding File Size\n");

    return e_success;
}

Status decode_secret_file_data(DecodeInfo *decInfo)
{
    printf("INFO: Decoding File Data\n");                                           
    decode_data_to_image(decInfo,decInfo -> fptr_desrc_image,decInfo -> stored_data);      // function decode data to image
    fwrite (decInfo -> magic_string,1,decInfo -> stored_data,decInfo -> fptr_desecret);    //// writing data from magic string to fptr desecret
    return e_success;

}
